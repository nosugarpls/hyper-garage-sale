import 'package:meta/meta.dart';

class Item {
  Item(
      {@required this.id,
      @required this.name,
      @required this.price,
      @required this.description,
      @required this.imageLocations});
  final String id;
  final String name;
  final int price;
  final String description;
  final List<String> imageLocations; // url

  factory Item.fromMap(Map<String, dynamic> data, String documentId) {
    if (data == null) {
      return null;
    }
    final name = data['name'] as String;
    final price = data['price'] as int;
    final description = data['description'] as String;
    final imageLocations = data['imageLocations'] == null
        ? null
        : List.castFrom<dynamic, String>(data['imageLocations'] as List);

    return Item(
        id: documentId,
        name: name,
        price: price,
        description: description,
        imageLocations: imageLocations);
  }

  Map<String, dynamic> toMap() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['name'] = name;
    data['price'] = price;
    data['description'] = description;
    data['imageLocations'] = imageLocations;
    return data;
  }
}
