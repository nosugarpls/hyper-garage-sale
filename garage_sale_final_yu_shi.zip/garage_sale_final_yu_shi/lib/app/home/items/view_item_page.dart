import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:garage_sale/app/home/models/item.dart';

class ViewItemPage extends StatefulWidget {
  final Item item;

  const ViewItemPage({Key key, this.item}) : super(key: key);

  @override
  _ViewItemPageState createState() => _ViewItemPageState();
}

class _ViewItemPageState extends State<ViewItemPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        iconTheme: IconThemeData(opacity: 20, color: Colors.black87),
      ),
      body: ListView(
        children: <Widget>[
          widget.item.imageLocations.isEmpty
              ? Image.asset('images/no-image-available.jpg')
              : _buildCarousel(),
          _buildListTile(),
          _buildDetails(),
        ],
      ),
    );
  }

  Widget _buildDetails() {
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.only(left: 40.0),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Description',
              style: TextStyle(fontSize: 20, color: Colors.black87),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
              left: 40.0, right: 40.0, bottom: 40.0, top: 10.0),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              widget.item.description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black87,
              ),
            ),
          ),
        )
      ],
    );
  }

  Widget _buildListTile() {
    return Padding(
      padding: const EdgeInsets.all(30.0),
      child: ListTile(
        title: Text(
          widget.item.name.toString(),
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        subtitle: Padding(
          padding: EdgeInsets.only(top: 8.0),
          child: Text(
            '\$ ' + widget.item.price.toString(),
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
        ),
        trailing: Icon(
          Icons.add_shopping_cart,
          size: 42,
          color: Colors.deepOrange,
        ),
      ),
    );
  }

  Widget _buildCarousel() {
    return CarouselSlider(
      options: CarouselOptions(
        height: 400.0,
        enableInfiniteScroll: true,
        autoPlay: true,
        autoPlayInterval: Duration(seconds: 3),
        autoPlayAnimationDuration: Duration(milliseconds: 800),
        autoPlayCurve: Curves.fastOutSlowIn,
        enlargeCenterPage: true,
      ),
      items: widget.item.imageLocations.map((url) {
        return Builder(
          builder: (context) {
            return Container(
              width: MediaQuery.of(context).size.width,
              child: CachedNetworkImage(
                imageUrl: url,
                imageBuilder: (context, imageProvider) => Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: imageProvider,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                placeholder: (context, url) => CircularProgressIndicator(),
              ),
            );
          },
        );
      }).toList(),
    );
  }
}
