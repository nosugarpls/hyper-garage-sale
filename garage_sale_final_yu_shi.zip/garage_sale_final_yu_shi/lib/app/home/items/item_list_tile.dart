import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:garage_sale/app/home/models/item.dart';

class ItemListTile extends StatelessWidget {
  const ItemListTile({Key key, @required this.item, this.onTap})
      : super(key: key);
  final Item item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: item.imageLocations.isEmpty
          ? Icon(Icons.image, size: 60)
          : CachedNetworkImage(
              imageUrl: item.imageLocations[0],
              imageBuilder: (context, imageProvider) => Image(
                image: imageProvider,
                width: 60,
              ),
              placeholder: (context, url) => CircularProgressIndicator(),
            ),
      title: Text(
        item.name.toString(),
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      subtitle: Text(
        '\$ ' + item.price.toString(),
        style: TextStyle(
            fontSize: 18, fontWeight: FontWeight.bold, color: Colors.brown),
      ),
      trailing: Icon(Icons.chevron_right, color: Colors.brown),
      onTap: onTap,
    );
  }
}
