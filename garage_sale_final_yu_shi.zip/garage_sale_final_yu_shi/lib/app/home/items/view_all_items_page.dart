import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:garage_sale/app/home/items/view_item_page.dart';
import 'package:garage_sale/app/home/models/item.dart';

import 'item_list_tile.dart';
import 'list_items_builder.dart';

class ViewAllItemsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Icon(Icons.storefront),
            Text('  Marketplace'),
          ],
        ),
        actions: <Widget>[
          FlatButton(
            child: Text(
              'Back',
              style: TextStyle(
                fontSize: 18.0,
                color: Colors.white,
              ),
            ),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
      body: _buildBody(context),
    );
  }

  Widget _buildBody(BuildContext context) {
    return StreamBuilder(
      stream: FirebaseFirestore.instance.collection('appitems').snapshots(),
      builder: (context, snapshot) {
        return ListItemsBuilder<Item>(
          snapshot: snapshot,
          itemBuilder: (context, item) => ItemListTile(
            item: item,
            onTap: () {
              Navigator.push<dynamic>(
                context,
                MaterialPageRoute<dynamic>(
                  builder: (context) => ViewItemPage(item: item),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
