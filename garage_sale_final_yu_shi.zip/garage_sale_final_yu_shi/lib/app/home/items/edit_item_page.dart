import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:garage_sale/app/home/models/item.dart';
import 'package:garage_sale/services/database.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:provider/provider.dart';

// When adding a new item, this page serves as add new item page.
// When editing an existing item, this page serves as editing item page.
class EditItemPage extends StatefulWidget {
  const EditItemPage({Key key, @required this.database, this.item})
      : super(key: key);
  final Database database;
  final Item item;

  static Future<void> show(BuildContext context, {Item item}) async {
    final database = Provider.of<Database>(context, listen: false);
    await Navigator.push<dynamic>(
      context,
      MaterialPageRoute<dynamic>(
        builder: (context) => EditItemPage(database: database, item: item),
        fullscreenDialog: true,
      ),
    );
  }

  @override
  _EditItemPageState createState() => _EditItemPageState();
}

class _EditItemPageState extends State<EditItemPage> {
  final _formKey = GlobalKey<FormState>();

  String _name;
  int _price;
  String _description;
  List<File> _imageFiles = []; // temp files
  List<String> _imageLocations = []; // url

  @override
  void initState() {
    super.initState();
    if (widget.item == null) return;
    _name = widget.item.name;
    _price = widget.item.price;
    _description = widget.item.description;
    _imageLocations = widget.item.imageLocations;
  }

  bool _validateAndSaveForm() {
    final form = _formKey.currentState;
    if (form.validate()) {
      form.save();
      return true;
    }
    return false;
  }

  Future<void> _uploadFiles() async {
    for (var i = 0; i < _imageFiles.length; i++) {
      var filename = path.basename(_imageFiles[i].path);
      var storageReference =
          FirebaseStorage.instance.ref().child('appimages/$filename');
      final uploadTask = storageReference.putFile(_imageFiles[i]);
      final downloadUrl = await uploadTask;
      final url = await downloadUrl.ref.getDownloadURL();
      _imageLocations[i] = url;
    }
  }

  Future<void> _submit() async {
    if (!_validateAndSaveForm()) return;
    await _uploadFiles(); // upload images & save urls
    final id = widget.item?.id ?? documentIdFromCurrentDate();
    final item = Item(
        id: id,
        name: _name,
        price: _price,
        description: _description,
        imageLocations: _imageLocations);
    await widget.database.setItem(item);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 2.0,
        title: Text(widget.item == null ? 'New Item' : 'Edit Item'),
        actions: <Widget>[
          FlatButton(
            child: Text(
              'Post',
              style: TextStyle(fontSize: 18, color: Colors.white),
            ),
            onPressed: _submit,
          ),
        ],
      ),
      body: _buildBody(),
      backgroundColor: Colors.grey[100],
    );
  }

  Widget _buildBody() {
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: _buildForm(),
            ),
          ),
        ),
        _buildImageWidgets(),
      ],
    );
  }

  Widget _buildForm() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: _buildTextFormFields(),
      ),
    );
  }

  List<Widget> _buildTextFormFields() {
    return [
      TextFormField(
        decoration: InputDecoration(labelText: 'Item name'),
        initialValue: _name,
        validator: (value) => value.isNotEmpty ? null : 'Name can\'t be empty',
        onSaved: (value) => _name = value,
      ),
      TextFormField(
        decoration: InputDecoration(labelText: 'Price'),
        initialValue: _price != null ? '$_price' : null,
        keyboardType: TextInputType.numberWithOptions(
          signed: false,
          decimal: false,
        ),
        onSaved: (value) => _price = int.tryParse(value) ?? 0,
      ),
      TextFormField(
        decoration: InputDecoration(labelText: 'Description'),
        initialValue: _description,
        validator: (value) =>
            value.isNotEmpty ? null : 'Description can\'t be empty',
        onSaved: (value) => _description = value,
      ),
    ];
  }

  Widget _buildImageWidgets() {
    List<Widget> list = List<Widget>();
    for (var i = 0; i < _imageFiles.length; i++) {
      list.add(
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: GestureDetector(
            onTap: () {
              _openCamera(context, i);
            },
            child: Image.file(
              _imageFiles[i],
              height: 100,
            ),
          ),
        ),
      );
    }
    if (list.length < 4) {
      list.add(
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: GestureDetector(
            onTap: () {
              _openCamera(context);
            },
            child: Image(
              image: AssetImage('images/add_new_image.png'),
              height: 100,
            ),
          ),
        ),
      );
    }
    return Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: list,
    );
  }

  void _openCamera(BuildContext context, [int image]) async {
    final picture = await ImagePicker().getImage(source: ImageSource.camera);
    if (picture == null) return;
    setState(
      () {
        if (image != null) {
          _imageFiles[image] = File(picture.path);
          _imageLocations[image] = picture.path;
        } else {
          _imageFiles.add(File(picture.path));
          _imageLocations.add(picture.path);
        }
      },
    );
  }
}
