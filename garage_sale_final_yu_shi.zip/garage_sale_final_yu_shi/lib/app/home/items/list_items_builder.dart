import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:garage_sale/app/home/models/item.dart';

import 'empty_content.dart';

typedef ItemWidgetBuilder<T> = Widget Function(BuildContext context, Item item);

class ListItemsBuilder<T> extends StatelessWidget {
  const ListItemsBuilder({
    Key key,
    this.snapshot,
    @required this.itemBuilder,
  }) : super(key: key);
  final AsyncSnapshot<dynamic> snapshot;
  final ItemWidgetBuilder<T> itemBuilder;

  @override
  Widget build(BuildContext context) {
    if (snapshot.hasData) {
      List items;

      if (snapshot.data is QuerySnapshot) {
        items = (snapshot.data as QuerySnapshot)
            .docs
            .map((e) => Item.fromMap(e.data(), e.id))
            .toList();
      } else {
        items = snapshot.data as List;
      }

      if (items.isNotEmpty) {
        return _buildList(items.cast<Item>());
      } else {
        return EmptyContent();
      }
    } else if (snapshot.hasError) {
      return EmptyContent(
        title: 'Something went wrong',
        message: 'Can\'t load items right now',
      );
    }
    return Center(child: CircularProgressIndicator());
  }

  Widget _buildList(List<Item> items) {
    return ListView.separated(
      itemCount: items.length + 2,
      separatorBuilder: (context, index) => Divider(height: 5.0),
      itemBuilder: (context, index) {
        if (index == 0 || index == items.length + 1) {
          return Container();
        }
        return itemBuilder(context, items[index - 1]);
      },
    );
  }
}
