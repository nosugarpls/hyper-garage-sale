import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:garage_sale/app/home/items/view_all_items_page.dart';
import 'package:garage_sale/app/home/models/item.dart';
import 'package:garage_sale/services/auth.dart';
import 'package:garage_sale/services/database.dart';
import 'package:provider/provider.dart';

import 'edit_item_page.dart';
import 'item_list_tile.dart';
import 'list_items_builder.dart';

class ItemsPage extends StatelessWidget {
  Future<void> _signOut(BuildContext context) async {
    try {
      final auth = Provider.of<AuthBase>(context, listen: false);
      await auth.signOut();
    } catch (e) {
      print(e.toString());
    }
  }

  Future<void> _delete(BuildContext context, Item item) async {
    try {
      final database = Provider.of<Database>(context, listen: false);
      await database.deleteItem(item);
    } on FirebaseException catch (e) {
      print(e.stackTrace);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Icon(Icons.build),
            Text('  My Garage'),
          ],
        ),
        actions: <Widget>[
          FlatButton(
            child: Text(
              'Logout',
              style: TextStyle(
                fontSize: 18.0,
                color: Colors.white,
              ),
            ),
            onPressed: () => _signOut(context),
          ),
        ],
      ),
      body: _buildBody(context),
      floatingActionButton: SpeedDial(
        backgroundColor: Colors.brown,
        animatedIcon: AnimatedIcons.menu_close,
        animatedIconTheme: IconThemeData(color: Colors.white),
        children: [
          SpeedDialChild(
            backgroundColor: Colors.brown[800],
            child: Icon(
              Icons.add,
              color: Colors.white,
            ),
            label: 'Post a new item',
            onTap: () => EditItemPage.show(context),
          ),
          SpeedDialChild(
            backgroundColor: Colors.brown[800],
            child: Icon(
              Icons.storefront,
              color: Colors.white,
            ),
            label: 'Go to marketplace',
            onTap: () {
              Navigator.push<dynamic>(
                context,
                MaterialPageRoute<dynamic>(
                  builder: (context) => ViewAllItemsPage(),
                  fullscreenDialog: true,
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildBody(BuildContext context) {
    final database = Provider.of<Database>(context, listen: false);
    return StreamBuilder<List<Item>>(
      stream: database.itemsStream(),
      builder: (context, snapshot) {
        return ListItemsBuilder<Item>(
          snapshot: snapshot,
          itemBuilder: (context, item) => Dismissible(
            key: Key('item-${item.id}'),
            background: Container(color: Colors.brown),
            direction: DismissDirection.endToStart,
            onDismissed: (direction) => _delete(context, item),
            child: ItemListTile(
              item: item,
              onTap: () => EditItemPage.show(context, item: item),
            ),
          ),
        );
      },
    );
  }
}
