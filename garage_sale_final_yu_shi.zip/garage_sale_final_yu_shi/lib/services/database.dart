import 'package:garage_sale/app/home/models/item.dart';
import 'package:meta/meta.dart';

import 'api_path.dart';
import 'firestore_service.dart';

abstract class Database {
  Future<void> setItem(Item item);
  Future<void> deleteItem(Item item);
  Stream<List<Item>> itemsStream();
}

String documentIdFromCurrentDate() => DateTime.now().toIso8601String();

class FirestoreDatabase implements Database {
  FirestoreDatabase({@required this.uid}) : assert(uid != null);
  final String uid;

  final _service = FirestoreService.instance;

  @override
  Future<void> setItem(Item item) {
    _service.setData(
      path: APIPath.item(uid, item.id),
      data: item.toMap(),
    ); // private
    _service.setData(
      path: 'appitems/${item.id}',
      data: item.toMap(),
    );
  }

  @override
  Future<void> deleteItem(Item item) {
    _service.deleteData(
      path: APIPath.item(uid, item.id),
    );
    _service.deleteData(
      path: 'appitems/${item.id}',
    );
  }

  @override
  Stream<List<Item>> itemsStream() => _service.collectionStream(
        path: APIPath.items(uid),
        builder: (data, documentId) => Item.fromMap(data, documentId),
      );
}
