class APIPath {
  static String item(String uid, String itemId) =>
      'appusers/$uid/items/$itemId';
  static String items(String uid) => 'appusers/$uid/items';
}
