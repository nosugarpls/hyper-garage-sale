# garage_sale

🐳 Watch demo on youtube:
https://youtu.be/otUd33qR2oU

🦀 Author:
https://nosugarpls.github.io/YCode-my-website/

🐣 A hyper garage sale app built with flutter.
1. Enhanced authentication flows with Google sign in service.
2. Managed the app states using the provider package.
3. Utilized Firebase Firestore as the main database to perform CRUD operations.
4. Utilized Firebase Storage to store large files such as image files.
5. Integrated the device camera into the image source.
6. Shopping cart and numerous new features(Maps, Real Time Dashboards, ML and more) to be developed soon.